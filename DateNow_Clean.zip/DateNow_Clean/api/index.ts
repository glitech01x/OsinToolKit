import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

// CONFIGURATION
let BASE_URL = 'https://securitydienetforces.pythonanywhere.com';
let TOKEN_GETTER: () => string | null = () => null;

export function setBaseUrl(url: string) {
  BASE_URL = url;
}

export function setAuthTokenGetter(getter: () => string | null) {
  TOKEN_GETTER = getter;
}

async function request<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const token = TOKEN_GETTER();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(token && { 'Authorization': `Bearer ${token}` }),
  };

  const res = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw err;
  }

  return res.json();
}

// ==============================================================================
// AUTH HOOKS
// ==============================================================================

interface LoginInput {
  data: { email: string; password: string };
}

interface RegisterInput {
  data: { 
    name: string; 
    email: string; 
    password: string; 
    age: number; 
    gender: 'male' | 'female' | 'other';
    bio?: string;
    location?: string;
  };
}

export function useLogin({ mutation }: any = {}) {
  return useMutation({
    mutationFn: (vars: LoginInput) => 
      request<{ token: string; user: any }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify(vars.data),
      }),
    ...mutation,
  });
}

export function useRegister({ mutation }: any = {}) {
  return useMutation({
    mutationFn: (vars: RegisterInput) =>
      request<{ token: string; user: any }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(vars.data),
      }),
    ...mutation,
  });
}

export function useGetMe() {
  return useQuery({
    queryKey: ['me'],
    queryFn: () => request<any>('/api/auth/me'), // Optional: if you add a /me endpoint to server
    enabled: false, // Disabled for now unless you build /me
  });
}

// ==============================================================================
// DATING HOOKS
// ==============================================================================

export function useListProfiles() {
  return useQuery({
    queryKey: ['profiles'],
    queryFn: () => request<any[]>('/api/profiles'),
  });
}

export function useLikeProfile({ mutation }: any = {}) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (vars: { id: number }) =>
      request<{ matched: boolean }>('/api/like', {
        method: 'POST',
        body: JSON.stringify({ targetId: vars.id }),
      }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['profiles'] }),
    ...mutation,
  });
}

export function usePassProfile({ mutation }: any = {}) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (vars: { id: number }) =>
      request('/api/pass', {
        method: 'POST',
        body: JSON.stringify({ targetId: vars.id }),
      }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['profiles'] }),
    ...mutation,
  });
}

// ==============================================================================
// LOCATION HOOKS
// ==============================================================================

export function useUpdateLocation() {
  return useMutation({
    mutationFn: (data: { data: { lat: number; lon: number } }) =>
      request('/api/user/location', { 
        method: 'POST', 
        body: JSON.stringify(data.data) 
      }),
  });
}

export function useGetNearbyUsers(args: any, options: any) {
  // Mock implementation for Nearby if not strictly needed for basic C2
  return useQuery({
    queryKey: ['nearby'],
    queryFn: () => Promise.resolve([]),
    ...options,
  });
}

// ==============================================================================
// MATCHES HOOKS
// ==============================================================================

export function useListMatches() {
  return useQuery({
    queryKey: ['matches'],
    queryFn: () => request<any[]>('/api/matches'),
  });
}

// ==============================================================================
// MESSAGES / CONVERSATIONS HOOKS
// ==============================================================================

export function useListConversations(args?: any, options?: any) {
  return useQuery({
    queryKey: ['conversations'],
    queryFn: () => request<any[]>('/api/conversations'),
    ...options,
  });
}

export function useGetMessages(profileId: number, options?: any) {
  return useQuery({
    queryKey: ['messages', profileId],
    queryFn: () => request<any[]>(`/api/messages/${profileId}`),
    enabled: !!profileId,
    ...options,
  });
}

interface SendMessageInput {
  profileId: number;
  data: { text: string };
}

export function useSendMessage({ mutation }: any = {}) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (vars: SendMessageInput) =>
      request(`/api/messages/${vars.profileId}`, {
        method: 'POST',
        body: JSON.stringify(vars.data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
    },
    ...mutation,
  });
}

// ==============================================================================
// QUERY KEYS
// ==============================================================================

export const getListMatchesQueryKey = () => ['matches'];
export const getListConversationsQueryKey = () => ['conversations'];
export const getListProfilesQueryKey = () => ['profiles'];
export const getGetMessagesQueryKey = (profileId: number) => ['messages', profileId];
