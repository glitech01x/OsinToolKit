const { execSync } = require('child_process');
const path = require('path');

const projectDir = path.resolve(__dirname, '..');

console.log('Building DateNow Mobile APK...');

try {
  execSync('npx eas build -p android --profile preview --local', {
    cwd: projectDir,
    stdio: 'inherit',
  });
} catch (e) {
  console.error('Build failed. Ensure EAS CLI is installed: npm install -g eas-cli');
  process.exit(1);
}
