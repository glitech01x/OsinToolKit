import { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator,
} from "react-native";
import { router } from "expo-router";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { useLogin } from "@/api";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function LoginScreen() {
  const colors = useColors();
  const { login } = useAuth();
  const insets = useSafeAreaInsets();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const s = makeStyles(colors);

  const loginMutation = useLogin({
    mutation: {
      onSuccess: async (data: any) => {
        await login(data.token, data.user as any);
        router.replace("/(app)/(tabs)/discover");
      },
      onError: () => setError("Invalid email or password"),
    },
  });

  return (
    <KeyboardAvoidingView
      style={[s.root, { paddingTop: insets.top, paddingBottom: insets.bottom + 24 }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled">
        <Text style={s.brand}>dateNow</Text>
        <Text style={s.subtitle}>Welcome back</Text>

        {error ? <View style={s.errorBox}><Text style={s.errorText}>{error}</Text></View> : null}

        <View style={s.field}>
          <Text style={s.label}>EMAIL</Text>
          <TextInput
            style={s.input}
            value={email}
            onChangeText={setEmail}
            placeholder="your@email.com"
            placeholderTextColor={colors.mutedForeground}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        <View style={s.field}>
          <Text style={s.label}>PASSWORD</Text>
          <TextInput
            style={s.input}
            value={password}
            onChangeText={setPassword}
            placeholder="••••••••"
            placeholderTextColor={colors.mutedForeground}
            secureTextEntry
          />
        </View>

        <TouchableOpacity
          style={[s.btn, loginMutation.isPending && s.btnDisabled]}
          onPress={() => {
            setError("");
            loginMutation.mutate({ data: { email, password } });
          }}
          disabled={loginMutation.isPending}
          activeOpacity={0.85}
        >
          {loginMutation.isPending
            ? <ActivityIndicator color={colors.primaryForeground} />
            : <Text style={s.btnText}>Sign In</Text>}
        </TouchableOpacity>

        <TouchableOpacity style={s.link} onPress={() => router.push("/(auth)/register")}>
          <Text style={s.linkText}>Not a member? <Text style={s.linkBold}>Apply now</Text></Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    scroll: { flexGrow: 1, justifyContent: "center", paddingHorizontal: 28 },
    brand: { fontSize: 36, fontStyle: "italic", color: colors.foreground, textAlign: "center", marginBottom: 8, fontFamily: "PlayfairDisplay_700Bold" },
    subtitle: { fontSize: 14, color: colors.mutedForeground, textAlign: "center", marginBottom: 36, letterSpacing: 0.3 },
    errorBox: { backgroundColor: "#a31f1f22", borderWidth: 1, borderColor: "#a31f1f44", borderRadius: colors.radius, padding: 12, marginBottom: 16 },
    errorText: { color: colors.destructive, fontSize: 13 },
    field: { marginBottom: 16 },
    label: { fontSize: 10, fontWeight: "600" as const, color: colors.mutedForeground, letterSpacing: 1.2, marginBottom: 6 },
    input: {
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: colors.radius,
      paddingHorizontal: 16,
      paddingVertical: 14,
      fontSize: 14,
      color: colors.foreground,
    },
    btn: {
      backgroundColor: colors.primary,
      borderRadius: colors.radius,
      height: 52,
      alignItems: "center",
      justifyContent: "center",
      marginTop: 8,
    },
    btnDisabled: { opacity: 0.6 },
    btnText: { color: colors.primaryForeground, fontSize: 15, fontWeight: "600" as const },
    link: { alignItems: "center", marginTop: 28 },
    linkText: { color: colors.mutedForeground, fontSize: 14 },
    linkBold: { color: colors.foreground, fontWeight: "600" as const },
  });
}
