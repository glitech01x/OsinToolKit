import { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, ActivityIndicator, Platform,
} from "react-native";
import { router } from "expo-router";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { useRegister } from "@/api";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Location from "expo-location";

export default function RegisterScreen() {
  const colors = useColors();
  const { login } = useAuth();
  const insets = useSafeAreaInsets();
  const s = makeStyles(colors);

  const [form, setForm] = useState({
    name: "", email: "", password: "", age: "", gender: "female", bio: "", location: "",
  });
  const [error, setError] = useState("");

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const genderOptions: Array<{ label: string; value: string }> = [
    { label: "Woman", value: "female" },
    { label: "Man", value: "male" },
    { label: "Other", value: "other" },
  ];

  const getLocation = async () => {
    if (Platform.OS === "web") return;
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status === "granted") {
      const loc = await Location.getCurrentPositionAsync({});
      const geo = await Location.reverseGeocodeAsync(loc.coords);
      if (geo[0]) {
        const { city, region, country } = geo[0];
        set("location", [city, region, country].filter(Boolean).join(", "));
      }
    }
  };

  const registerMutation = useRegister({
    mutation: {
      onSuccess: async (data: any) => {
        await login(data.token, data.user as any);
        router.replace("/(app)/(tabs)/discover");
      },
      onError: (e: any) => setError(e?.data?.error || "Registration failed"),
    },
  });

  const handleSubmit = () => {
    setError("");
    registerMutation.mutate({
      data: {
        name: form.name,
        email: form.email,
        password: form.password,
        age: parseInt(form.age) || 18,
        gender: form.gender as "male" | "female" | "other",
        bio: form.bio || undefined,
        location: form.location || undefined,
      },
    });
  };

  return (
    <ScrollView
      style={[s.root, { paddingTop: insets.top }]}
      contentContainerStyle={[s.scroll, { paddingBottom: insets.bottom + 24 }]}
      keyboardShouldPersistTaps="handled"
    >
      <Text style={s.brand}>dateNow</Text>
      <Text style={s.subtitle}>Create your profile</Text>

      {error ? <View style={s.errorBox}><Text style={s.errorText}>{error}</Text></View> : null}

      <View style={s.field}>
        <Text style={s.label}>FULL NAME</Text>
        <TextInput style={s.input} value={form.name} onChangeText={v => set("name", v)}
          placeholder="Your name" placeholderTextColor={colors.mutedForeground} />
      </View>

      <View style={s.field}>
        <Text style={s.label}>EMAIL</Text>
        <TextInput style={s.input} value={form.email} onChangeText={v => set("email", v)}
          placeholder="your@email.com" placeholderTextColor={colors.mutedForeground}
          keyboardType="email-address" autoCapitalize="none" />
      </View>

      <View style={s.field}>
        <Text style={s.label}>PASSWORD</Text>
        <TextInput style={s.input} value={form.password} onChangeText={v => set("password", v)}
          placeholder="At least 6 characters" placeholderTextColor={colors.mutedForeground}
          secureTextEntry />
      </View>

      <View style={s.row}>
        <View style={[s.field, { flex: 1, marginRight: 8 }]}>
          <Text style={s.label}>AGE</Text>
          <TextInput style={s.input} value={form.age} onChangeText={v => set("age", v)}
            placeholder="25" placeholderTextColor={colors.mutedForeground}
            keyboardType="number-pad" />
        </View>
        <View style={[s.field, { flex: 1.5 }]}>
          <Text style={s.label}>I AM</Text>
          <View style={s.genderRow}>
            {genderOptions.map(opt => (
              <TouchableOpacity
                key={opt.value}
                style={[s.genderBtn, form.gender === opt.value && s.genderBtnActive]}
                onPress={() => set("gender", opt.value)}
              >
                <Text style={[s.genderText, form.gender === opt.value && s.genderTextActive]}>
                  {opt.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </View>

      <View style={s.field}>
        <View style={s.locationRow}>
          <Text style={s.label}>LOCATION</Text>
          <TouchableOpacity onPress={getLocation}>
            <Text style={s.detectText}>Detect</Text>
          </TouchableOpacity>
        </View>
        <TextInput style={s.input} value={form.location} onChangeText={v => set("location", v)}
          placeholder="City, Country" placeholderTextColor={colors.mutedForeground} />
      </View>

      <View style={s.field}>
        <Text style={s.label}>ABOUT YOU</Text>
        <TextInput style={[s.input, s.textarea]} value={form.bio} onChangeText={v => set("bio", v)}
          placeholder="A few words about yourself..." placeholderTextColor={colors.mutedForeground}
          multiline numberOfLines={3} textAlignVertical="top" />
      </View>

      <TouchableOpacity
        style={[s.btn, registerMutation.isPending && s.btnDisabled]}
        onPress={handleSubmit}
        disabled={registerMutation.isPending}
        activeOpacity={0.85}
      >
        {registerMutation.isPending
          ? <ActivityIndicator color={colors.primaryForeground} />
          : <Text style={s.btnText}>Join dateNow</Text>}
      </TouchableOpacity>

      <TouchableOpacity style={s.link} onPress={() => router.push("/(auth)/login")}>
        <Text style={s.linkText}>Already a member? <Text style={s.linkBold}>Sign in</Text></Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    scroll: { paddingHorizontal: 28 },
    brand: { fontSize: 36, fontStyle: "italic", color: colors.foreground, textAlign: "center", marginBottom: 8, marginTop: 12, fontFamily: "PlayfairDisplay_700Bold" },
    subtitle: { fontSize: 14, color: colors.mutedForeground, textAlign: "center", marginBottom: 28, letterSpacing: 0.3 },
    errorBox: { backgroundColor: "#a31f1f22", borderWidth: 1, borderColor: "#a31f1f44", borderRadius: colors.radius, padding: 12, marginBottom: 16 },
    errorText: { color: colors.destructive, fontSize: 13 },
    field: { marginBottom: 14 },
    label: { fontSize: 10, fontWeight: "600" as const, color: colors.mutedForeground, letterSpacing: 1.2, marginBottom: 6 },
    input: {
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: colors.radius,
      paddingHorizontal: 16,
      paddingVertical: 13,
      fontSize: 14,
      color: colors.foreground,
    },
    textarea: { height: 80, paddingTop: 13 },
    row: { flexDirection: "row" },
    locationRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 6 },
    detectText: { fontSize: 12, color: colors.primary, fontWeight: "600" as const },
    genderRow: { flexDirection: "row", gap: 6 },
    genderBtn: {
      flex: 1,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: colors.radius,
      paddingVertical: 13,
      alignItems: "center",
    },
    genderBtnActive: { borderColor: colors.primary, backgroundColor: colors.accent },
    genderText: { fontSize: 12, color: colors.mutedForeground },
    genderTextActive: { color: colors.primaryForeground, fontWeight: "600" as const },
    btn: {
      backgroundColor: colors.primary,
      borderRadius: colors.radius,
      height: 52,
      alignItems: "center",
      justifyContent: "center",
      marginTop: 8,
    },
    btnDisabled: { opacity: 0.6 },
    btnText: { color: colors.primaryForeground, fontSize: 15, fontWeight: "600" as const },
    link: { alignItems: "center", marginTop: 24 },
    linkText: { color: colors.mutedForeground, fontSize: 14 },
    linkBold: { color: colors.foreground, fontWeight: "600" as const },
  });
}
