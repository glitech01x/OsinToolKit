import { useState, useCallback } from "react";
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  FlatList, Image, ActivityIndicator, Platform,
} from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import { useLocalSearchParams, router } from "expo-router";
import { useColors } from "@/hooks/useColors";
import {
  useGetMessages, useSendMessage, useListConversations,
  getGetMessagesQueryKey, getListConversationsQueryKey,
} from "@/api";
import { useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";

export default function ChatScreen() {
  const { profileId } = useLocalSearchParams<{ profileId: string }>();
  const id = parseInt(profileId || "0");
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const [text, setText] = useState("");
  const s = makeStyles(colors);

  const { data: conversationsRaw = [] } = useListConversations();
  const conversations = conversationsRaw as any[];
  const conv = conversations.find((c: any) => c.profileId === id);
  const profile = conv?.profile;

  const { data: messagesRaw = [], isLoading } = useGetMessages(id, {
    query: {
      queryKey: getGetMessagesQueryKey(id),
      refetchInterval: 5000,
      enabled: !!id,
    },
  });
  const messages = messagesRaw as any[];

  const send = useSendMessage({
    mutation: {
      onSuccess: () => {
        setText("");
        queryClient.invalidateQueries({ queryKey: getGetMessagesQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      },
    },
  });

  const reversed = [...messages].reverse();

  const renderItem = useCallback(({ item }: { item: typeof messages[0] }) => {
    const isUser = item.senderType === "user";
    return (
      <View style={[s.msgRow, isUser ? s.msgRowUser : s.msgRowProfile]}>
        {!isUser && profile && (
          <Image source={{ uri: profile.photoUrl }} style={s.msgAvatar} />
        )}
        <View style={[s.bubble, isUser ? s.bubbleUser : s.bubbleProfile]}>
          <Text style={[s.bubbleText, isUser ? s.bubbleTextUser : s.bubbleTextProfile]}>
            {item.text}
          </Text>
          <Text style={[s.bubbleTime, isUser ? s.bubbleTimeUser : s.bubbleTimeProfile]}>
            {new Date(item.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </Text>
        </View>
      </View>
    );
  }, [profile, s]);

  return (
    <View style={[s.root, { paddingTop: Platform.OS === "web" ? insets.top + 67 : insets.top }]}>
      <View style={s.header}>
        <TouchableOpacity onPress={() => router.back()} style={s.backBtn} activeOpacity={0.7}>
          <Ionicons name="chevron-back" size={24} color={colors.foreground} />
        </TouchableOpacity>
        {profile ? (
          <View style={s.headerInfo}>
            <Image source={{ uri: profile.photoUrl }} style={s.headerAvatar} />
            <View>
              <Text style={s.headerName}>{profile.name}</Text>
              <Text style={s.headerAge}>{profile.age}{profile.location ? " · " + profile.location : ""}</Text>
            </View>
          </View>
        ) : <View />}
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior="padding"
        keyboardVerticalOffset={0}
      >
        {isLoading ? (
          <View style={s.center}>
            <ActivityIndicator color={colors.primary} size="large" />
          </View>
        ) : (
          <FlatList
            data={reversed}
            keyExtractor={item => String(item.id)}
            renderItem={renderItem}
            inverted
            contentContainerStyle={s.messagesList}
            keyboardDismissMode="interactive"
            keyboardShouldPersistTaps="handled"
            scrollEnabled={!!reversed.length}
            ListEmptyComponent={
              <View style={s.center}>
                {profile && <Image source={{ uri: profile.photoUrl }} style={s.emptyAvatar} />}
                <Text style={s.emptyText}>Say hello to {profile?.name}</Text>
              </View>
            }
          />
        )}

        <View style={[s.inputRow, { paddingBottom: insets.bottom + 8 }]}>
          <TextInput
            style={s.input}
            value={text}
            onChangeText={setText}
            placeholder={`Message ${profile?.name || ""}...`}
            placeholderTextColor={colors.mutedForeground}
            multiline
          />
          <TouchableOpacity
            style={[s.sendBtn, !text.trim() && s.sendBtnDisabled]}
            onPress={() => { if (text.trim()) send.mutate({ profileId: id, data: { text: text.trim() } }); }}
            disabled={!text.trim() || send.isPending}
            activeOpacity={0.8}
          >
            <Ionicons name="send" size={18} color={colors.primaryForeground} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: {
      flexDirection: "row",
      alignItems: "center",
      paddingHorizontal: 12,
      paddingVertical: 10,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
      gap: 8,
    },
    backBtn: { padding: 4 },
    headerInfo: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1 },
    headerAvatar: { width: 38, height: 38, borderRadius: 19 },
    headerName: { fontSize: 15, fontWeight: "600" as const, color: colors.foreground },
    headerAge: { fontSize: 12, color: colors.mutedForeground },
    center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12, transform: [{ scaleY: -1 }] },
    emptyAvatar: { width: 70, height: 70, borderRadius: 35, borderWidth: 2, borderColor: colors.border },
    emptyText: { fontSize: 14, color: colors.mutedForeground },
    messagesList: { paddingHorizontal: 16, paddingVertical: 12, gap: 10 },
    msgRow: { flexDirection: "row", alignItems: "flex-end", gap: 8 },
    msgRowUser: { justifyContent: "flex-end" },
    msgRowProfile: { justifyContent: "flex-start" },
    msgAvatar: { width: 28, height: 28, borderRadius: 14 },
    bubble: {
      maxWidth: "72%",
      borderRadius: 18,
      paddingHorizontal: 14,
      paddingVertical: 10,
    },
    bubbleUser: { backgroundColor: colors.primary, borderBottomRightRadius: 4 },
    bubbleProfile: { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderBottomLeftRadius: 4 },
    bubbleText: { fontSize: 14, lineHeight: 20 },
    bubbleTextUser: { color: colors.primaryForeground },
    bubbleTextProfile: { color: colors.foreground },
    bubbleTime: { fontSize: 10, marginTop: 4 },
    bubbleTimeUser: { color: "rgba(255,255,255,0.5)", textAlign: "right" },
    bubbleTimeProfile: { color: colors.mutedForeground },
    inputRow: {
      flexDirection: "row",
      alignItems: "flex-end",
      gap: 10,
      paddingHorizontal: 16,
      paddingTop: 10,
      borderTopWidth: 1,
      borderTopColor: colors.border,
      backgroundColor: colors.background,
    },
    input: {
      flex: 1,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: 22,
      paddingHorizontal: 16,
      paddingVertical: 10,
      fontSize: 14,
      color: colors.foreground,
      maxHeight: 100,
    },
    sendBtn: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor: colors.primary,
      alignItems: "center",
      justifyContent: "center",
    },
    sendBtnDisabled: { opacity: 0.4 },
  });
}
