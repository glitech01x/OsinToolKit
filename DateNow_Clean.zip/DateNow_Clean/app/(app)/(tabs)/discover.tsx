import { useState, useRef, useCallback } from "react";
import {
  View, Text, StyleSheet, Image, Dimensions, PanResponder,
  Animated, TouchableOpacity, ActivityIndicator, Platform,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { useListProfiles, useLikeProfile, usePassProfile } from "@/api";
import { useQueryClient } from "@tanstack/react-query";
import { getListMatchesQueryKey, getListConversationsQueryKey, getListProfilesQueryKey } from "@/api";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get("window");
const CARD_W = SCREEN_W - 32;
const CARD_H = SCREEN_H * 0.62;
const SWIPE_THRESHOLD = SCREEN_W * 0.35;

type Profile = {
  id: number;
  name: string;
  age: number;
  gender: string;
  bio: string | null;
  location: string | null;
  photoUrl: string;
  interests: string | null;
  online: boolean;
};

function ProfileCardAnimated({
  profile,
  onLike,
  onPass,
  colors,
}: {
  profile: Profile;
  onLike: () => void;
  onPass: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  const pan = useRef(new Animated.ValueXY()).current;
  const rotate = pan.x.interpolate({ inputRange: [-SCREEN_W / 2, 0, SCREEN_W / 2], outputRange: ["-12deg", "0deg", "12deg"] });
  const likeOpacity = pan.x.interpolate({ inputRange: [-20, 0, 80], outputRange: [0, 0, 1] });
  const passOpacity = pan.x.interpolate({ inputRange: [-80, 0, 20], outputRange: [1, 0, 0] });

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderMove: (_, g) => pan.setValue({ x: g.dx, y: g.dy }),
      onPanResponderRelease: (_, g) => {
        if (g.dx > SWIPE_THRESHOLD) {
          Animated.timing(pan, { toValue: { x: SCREEN_W * 1.5, y: g.dy }, duration: 250, useNativeDriver: true }).start(onLike);
        } else if (g.dx < -SWIPE_THRESHOLD) {
          Animated.timing(pan, { toValue: { x: -SCREEN_W * 1.5, y: g.dy }, duration: 250, useNativeDriver: true }).start(onPass);
        } else {
          Animated.spring(pan, { toValue: { x: 0, y: 0 }, useNativeDriver: true }).start();
        }
      },
    })
  ).current;

  const s = StyleSheet.create({
    card: {
      width: CARD_W,
      height: CARD_H,
      borderRadius: 20,
      overflow: "hidden",
      backgroundColor: colors.card,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 8 },
      shadowOpacity: 0.4,
      shadowRadius: 20,
      elevation: 12,
    },
    image: { width: "100%", height: "100%" },
    gradient: {
      position: "absolute",
      bottom: 0,
      left: 0,
      right: 0,
      height: CARD_H * 0.55,
      backgroundColor: "transparent",
    },
    info: { position: "absolute", bottom: 0, left: 0, right: 0, padding: 20 },
    name: { color: "#fff", fontSize: 26, fontWeight: "700" as const, fontFamily: "PlayfairDisplay_700Bold" },
    age: { color: "rgba(255,255,255,0.75)", fontSize: 18, fontWeight: "400" as const },
    location: { color: "rgba(255,255,255,0.6)", fontSize: 13, marginTop: 2 },
    bio: { color: "rgba(255,255,255,0.7)", fontSize: 13, marginTop: 6, lineHeight: 18 },
    onlineDot: {
      position: "absolute",
      top: 16,
      right: 16,
      backgroundColor: "#10b981",
      width: 10,
      height: 10,
      borderRadius: 5,
    },
    likeLabel: {
      position: "absolute",
      top: 32,
      left: 20,
      borderWidth: 3,
      borderColor: "#10b981",
      borderRadius: 8,
      paddingHorizontal: 10,
      paddingVertical: 4,
      transform: [{ rotate: "-20deg" }],
    },
    likeLabelText: { color: "#10b981", fontSize: 22, fontWeight: "800" as const },
    passLabel: {
      position: "absolute",
      top: 32,
      right: 20,
      borderWidth: 3,
      borderColor: colors.destructive,
      borderRadius: 8,
      paddingHorizontal: 10,
      paddingVertical: 4,
      transform: [{ rotate: "20deg" }],
    },
    passLabelText: { color: colors.destructive, fontSize: 22, fontWeight: "800" as const },
    interests: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 8 },
    tag: {
      backgroundColor: "rgba(255,255,255,0.12)",
      borderRadius: 12,
      paddingHorizontal: 10,
      paddingVertical: 3,
    },
    tagText: { color: "rgba(255,255,255,0.8)", fontSize: 11 },
  });

  return (
    <Animated.View
      {...panResponder.panHandlers}
      style={[
        StyleSheet.absoluteFill,
        { alignItems: "center", justifyContent: "center" },
        { transform: [{ translateX: pan.x }, { translateY: pan.y }, { rotate }] },
      ]}
    >
      <View style={s.card}>
        <Image source={{ uri: profile.photoUrl }} style={s.image} resizeMode="cover" />
        <View
          style={[
            s.gradient,
            {
              shadowColor: "#000",
              shadowOffset: { width: 0, height: -80 },
              shadowOpacity: 1,
              shadowRadius: 60,
              backgroundColor: "rgba(0,0,0,0.65)",
            },
          ]}
        />
        {profile.online && <View style={s.onlineDot} />}
        <Animated.View style={[s.likeLabel, { opacity: likeOpacity }]}>
          <Text style={s.likeLabelText}>LIKE</Text>
        </Animated.View>
        <Animated.View style={[s.passLabel, { opacity: passOpacity }]}>
          <Text style={s.passLabelText}>NOPE</Text>
        </Animated.View>
        <View style={s.info}>
          <Text style={s.name}>{profile.name}<Text style={s.age}>, {profile.age}</Text></Text>
          {profile.location ? <Text style={s.location}>{profile.location}</Text> : null}
          {profile.bio ? <Text style={s.bio} numberOfLines={2}>{profile.bio}</Text> : null}
          {profile.interests ? (
            <View style={s.interests}>
              {profile.interests.split(",").slice(0, 3).map(t => (
                <View key={t} style={s.tag}><Text style={s.tagText}>{t.trim()}</Text></View>
              ))}
            </View>
          ) : null}
        </View>
      </View>
    </Animated.View>
  );
}

export default function DiscoverScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [matchedProfile, setMatchedProfile] = useState<Profile | null>(null);

  const { data: profiles = [], isLoading } = useListProfiles();

  const like = useLikeProfile({
    mutation: {
      onSuccess: (data: any) => {
        queryClient.invalidateQueries({ queryKey: getListProfilesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListMatchesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
        if (data.matched) {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          setMatchedProfile(profiles[currentIndex] as Profile);
        }
        setCurrentIndex(i => i + 1);
      },
    },
  });

  const pass = usePassProfile({
    mutation: {
      onSuccess: () => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        setCurrentIndex(i => i + 1);
      },
    },
  });

  const profile = profiles[currentIndex] as Profile | undefined;
  const s = makeStyles(colors);

  if (isLoading) {
    return (
      <View style={[s.root, { paddingTop: insets.top }]}>
        <View style={s.center}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      </View>
    );
  }

  if (!profile) {
    return (
      <View style={[s.root, { paddingTop: insets.top }]}>
        <View style={s.center}>
          <Ionicons name="heart-dislike-outline" size={56} color={colors.mutedForeground} />
          <Text style={s.emptyTitle}>You've seen everyone</Text>
          <Text style={s.emptyText}>Check back later for new members</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[s.root, { paddingTop: insets.top }]}>
      <View style={s.header}>
        <Text style={s.brand}>dateNow</Text>
        <Text style={s.remaining}>{profiles.length - currentIndex} left</Text>
      </View>

      <View style={s.cardArea}>
        {profiles.slice(currentIndex + 1, currentIndex + 3).reverse().map((p, i) => (
          <View
            key={(p as Profile).id + "_bg"}
            style={[
              StyleSheet.absoluteFill,
              {
                alignItems: "center",
                justifyContent: "center",
                transform: [{ scale: 0.96 - i * 0.03 }, { translateY: 10 + i * 8 }],
                zIndex: i,
              },
            ]}
          >
            <View style={[s.cardShadow, { width: CARD_W, height: CARD_H, borderRadius: 20, overflow: "hidden" }]}>
              <Image source={{ uri: (p as Profile).photoUrl }} style={{ width: "100%", height: "100%" }} resizeMode="cover" />
            </View>
          </View>
        ))}

        <ProfileCardAnimated
          key={profile.id}
          profile={profile}
          colors={colors}
          onLike={() => like.mutate({ id: profile.id })}
          onPass={() => pass.mutate({ id: profile.id })}
        />
      </View>

      <View style={[s.actions, { paddingBottom: insets.bottom + 80 }]}>
        <TouchableOpacity
          style={s.passBtn}
          onPress={() => pass.mutate({ id: profile.id })}
          activeOpacity={0.75}
        >
          <Ionicons name="close" size={32} color={colors.destructive} />
        </TouchableOpacity>

        <TouchableOpacity
          style={s.likeBtn}
          onPress={() => like.mutate({ id: profile.id })}
          activeOpacity={0.75}
        >
          <Ionicons name="heart" size={36} color={colors.primaryForeground} />
        </TouchableOpacity>

        <TouchableOpacity style={s.passBtn} activeOpacity={0.75}>
          <Ionicons name="star" size={24} color="#f59e0b" />
        </TouchableOpacity>
      </View>

      {matchedProfile && (
        <View style={[StyleSheet.absoluteFill, s.matchOverlay]}>
          <Image source={{ uri: matchedProfile.photoUrl }} style={s.matchPhoto} />
          <Text style={s.matchTitle}>It's a Match</Text>
          <Text style={s.matchSub}>You and {matchedProfile.name} liked each other</Text>
          <TouchableOpacity
            style={s.matchBtn}
            onPress={() => setMatchedProfile(null)}
            activeOpacity={0.85}
          >
            <Text style={s.matchBtnText}>Keep browsing</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      paddingHorizontal: 20,
      paddingVertical: 12,
    },
    brand: { fontSize: 22, fontStyle: "italic", color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold" },
    remaining: { fontSize: 12, color: colors.mutedForeground },
    cardArea: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
    },
    cardShadow: {
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.3,
      shadowRadius: 12,
      elevation: 6,
    },
    actions: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 24,
      paddingTop: 16,
    },
    passBtn: {
      width: 60,
      height: 60,
      borderRadius: 30,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
      alignItems: "center",
      justifyContent: "center",
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.2,
      shadowRadius: 8,
      elevation: 4,
    },
    likeBtn: {
      width: 76,
      height: 76,
      borderRadius: 38,
      backgroundColor: colors.primary,
      alignItems: "center",
      justifyContent: "center",
      shadowColor: colors.primary,
      shadowOffset: { width: 0, height: 8 },
      shadowOpacity: 0.4,
      shadowRadius: 16,
      elevation: 8,
    },
    center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12, padding: 24 },
    emptyTitle: { fontSize: 22, color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold", textAlign: "center" },
    emptyText: { fontSize: 14, color: colors.mutedForeground, textAlign: "center" },
    matchOverlay: {
      backgroundColor: "rgba(0,0,0,0.92)",
      alignItems: "center",
      justifyContent: "center",
      gap: 16,
      zIndex: 100,
    },
    matchPhoto: { width: 140, height: 140, borderRadius: 70, borderWidth: 3, borderColor: colors.primary },
    matchTitle: { fontSize: 32, color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold" },
    matchSub: { fontSize: 15, color: colors.mutedForeground, textAlign: "center" },
    matchBtn: {
      backgroundColor: colors.primary,
      borderRadius: colors.radius,
      paddingHorizontal: 32,
      paddingVertical: 14,
      marginTop: 8,
    },
    matchBtnText: { color: colors.primaryForeground, fontSize: 15, fontWeight: "600" as const },
  });
}
