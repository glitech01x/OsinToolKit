import {
  View, Text, Image, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, Platform, Dimensions,
} from "react-native";
import { useColors } from "@/hooks/useColors";
import { useListMatches } from "@/api";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const CARD_SIZE = (Dimensions.get("window").width - 32 - 12) / 2;

export default function MatchesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data: matches = [], isLoading } = useListMatches();
  const s = makeStyles(colors);

  return (
    <View style={[s.root, { paddingTop: insets.top + (Platform.OS === "web" ? 67 : 0) }]}>
      <View style={s.header}>
        <Text style={s.title}>Matches</Text>
        {matches.length > 0 && <Text style={s.count}>{matches.length}</Text>}
      </View>

      {isLoading ? (
        <View style={s.center}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      ) : matches.length === 0 ? (
        <View style={s.center}>
          <Ionicons name="heart-outline" size={52} color={colors.mutedForeground} />
          <Text style={s.emptyTitle}>No matches yet</Text>
          <Text style={s.emptyText}>Start liking profiles to get matches</Text>
          <TouchableOpacity style={s.discoverBtn} onPress={() => router.push("/(app)/(tabs)/discover")} activeOpacity={0.85}>
            <Text style={s.discoverBtnText}>Discover profiles</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={matches}
          keyExtractor={item => String(item.id)}
          numColumns={2}
          contentContainerStyle={[s.grid, { paddingBottom: insets.bottom + 80 }]}
          columnWrapperStyle={{ gap: 12 }}
          scrollEnabled={matches.length > 0}
          renderItem={({ item }) => {
            const p = item.profile;
            if (!p) return null;
            return (
              <TouchableOpacity
                style={s.card}
                onPress={() => router.push(`/(app)/chat/${p.id}` as any)}
                activeOpacity={0.85}
              >
                <Image source={{ uri: p.photoUrl }} style={s.photo} resizeMode="cover" />
                <View style={s.cardOverlay} />
                {p.online && <View style={s.onlineDot} />}
                <View style={s.cardInfo}>
                  <Text style={s.cardName} numberOfLines={1}>{p.name}</Text>
                  <Text style={s.cardAge}>{p.age}</Text>
                </View>
              </TouchableOpacity>
            );
          }}
        />
      )}
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 20, paddingVertical: 16 },
    title: { fontSize: 26, color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold" },
    count: { fontSize: 14, color: colors.mutedForeground, marginTop: 4 },
    grid: { paddingHorizontal: 16, gap: 12 },
    card: {
      width: CARD_SIZE,
      height: CARD_SIZE * 1.35,
      borderRadius: 16,
      overflow: "hidden",
      backgroundColor: colors.card,
    },
    photo: { width: "100%", height: "100%" },
    cardOverlay: { position: "absolute", bottom: 0, left: 0, right: 0, height: "50%", backgroundColor: "rgba(0,0,0,0.5)" },
    onlineDot: { position: "absolute", top: 10, right: 10, width: 10, height: 10, borderRadius: 5, backgroundColor: "#10b981" },
    cardInfo: { position: "absolute", bottom: 0, left: 0, right: 0, padding: 12 },
    cardName: { color: "#fff", fontSize: 15, fontWeight: "700" as const },
    cardAge: { color: "rgba(255,255,255,0.7)", fontSize: 12 },
    center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
    emptyTitle: { fontSize: 20, color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold" },
    emptyText: { fontSize: 14, color: colors.mutedForeground },
    discoverBtn: { backgroundColor: colors.primary, borderRadius: colors.radius, paddingHorizontal: 24, paddingVertical: 12, marginTop: 8 },
    discoverBtnText: { color: colors.primaryForeground, fontSize: 14, fontWeight: "600" as const },
  });
}
