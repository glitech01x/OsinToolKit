import { View, Text, Image, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator } from "react-native";
import { useColors } from "@/hooks/useColors";
import { useListConversations, getListConversationsQueryKey } from "@/api";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Platform } from "react-native";

export default function MessagesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const s = makeStyles(colors);

  const { data: conversationsRaw = [], isLoading } = useListConversations({
    query: {
      queryKey: getListConversationsQueryKey(),
      refetchInterval: 5000,
    },
  });
  const conversations = conversationsRaw as any[];

  return (
    <View style={[s.root, { paddingTop: insets.top + (Platform.OS === "web" ? 67 : 0) }]}>
      <View style={s.header}>
        <Text style={s.title}>Messages</Text>
      </View>

      {isLoading ? (
        <View style={s.center}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      ) : conversations.length === 0 ? (
        <View style={s.center}>
          <Ionicons name="chatbubbles-outline" size={52} color={colors.mutedForeground} />
          <Text style={s.emptyTitle}>No conversations</Text>
          <Text style={s.emptyText}>Match with someone to start chatting</Text>
        </View>
      ) : (
        <FlatList
          data={conversations}
          keyExtractor={item => String(item.id)}
          contentContainerStyle={{ paddingBottom: insets.bottom + 80 }}
          scrollEnabled={conversations.length > 0}
          ItemSeparatorComponent={() => <View style={s.separator} />}
          renderItem={({ item }) => {
            const p = item.profile;
            if (!p) return null;
            return (
              <TouchableOpacity
                style={s.row}
                onPress={() => router.push(`/(app)/chat/${p.id}`)}
                activeOpacity={0.75}
              >
                <View style={s.avatarWrap}>
                  <Image source={{ uri: p.photoUrl }} style={s.avatar} />
                  {p.online && <View style={s.onlineDot} />}
                </View>
                <View style={s.info}>
                  <View style={s.infoTop}>
                    <Text style={s.name}>{p.name}</Text>
                    {item.lastMessageAt && (
                      <Text style={s.time}>
                        {new Date(item.lastMessageAt).toLocaleDateString([], { month: "short", day: "numeric" })}
                      </Text>
                    )}
                  </View>
                  {item.lastMessage ? (
                    <Text style={s.preview} numberOfLines={1}>{item.lastMessage}</Text>
                  ) : (
                    <Text style={[s.preview, { fontStyle: "italic" }]}>Say hello...</Text>
                  )}
                </View>
              </TouchableOpacity>
            );
          }}
        />
      )}
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: { paddingHorizontal: 20, paddingVertical: 16 },
    title: { fontSize: 26, color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold" },
    row: { flexDirection: "row", alignItems: "center", paddingHorizontal: 20, paddingVertical: 14, gap: 14 },
    avatarWrap: { position: "relative" },
    avatar: { width: 52, height: 52, borderRadius: 26 },
    onlineDot: { position: "absolute", bottom: 1, right: 1, width: 12, height: 12, borderRadius: 6, backgroundColor: "#10b981", borderWidth: 2, borderColor: colors.background },
    info: { flex: 1 },
    infoTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
    name: { fontSize: 15, fontWeight: "600" as const, color: colors.foreground },
    time: { fontSize: 12, color: colors.mutedForeground },
    preview: { fontSize: 13, color: colors.mutedForeground, marginTop: 2 },
    separator: { height: 1, backgroundColor: colors.border, marginLeft: 84 },
    center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
    emptyTitle: { fontSize: 20, color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold" },
    emptyText: { fontSize: 14, color: colors.mutedForeground },
  });
}
