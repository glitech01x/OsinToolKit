import { useEffect, useRef, useState, useCallback } from "react";
import {
  View, Text, StyleSheet, FlatList, Image,
  TouchableOpacity, ActivityIndicator, Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as Location from "expo-location";
import { useColors } from "@/hooks/useColors";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useGetNearbyUsers, useUpdateLocation } from "@/api";

type NearbyUser = {
  id: number;
  name: string;
  age: number;
  gender: string;
  bio?: string | null;
  location?: string | null;
  avatarUrl?: string | null;
  distanceKm: number;
  locationUpdatedAt?: string | null;
};

const DEFAULT_AVATAR = "https://api.dicebear.com/9.x/personas/svg?seed=default";

function UserCard({ user, colors }: { user: NearbyUser; colors: ReturnType<typeof useColors> }) {
  const s = StyleSheet.create({
    card: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: colors.card,
      borderRadius: 16,
      padding: 14,
      marginHorizontal: 16,
      marginBottom: 10,
      borderWidth: 1,
      borderColor: colors.border,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.12,
      shadowRadius: 6,
      elevation: 3,
    },
    avatar: { width: 58, height: 58, borderRadius: 29, marginRight: 14, backgroundColor: colors.muted },
    info: { flex: 1 },
    name: { fontSize: 16, fontWeight: "700" as const, color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold" },
    sub: { fontSize: 13, color: colors.mutedForeground, marginTop: 2 },
    bio: { fontSize: 12, color: colors.mutedForeground, marginTop: 4 },
    badge: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      backgroundColor: colors.primary + "20",
      borderRadius: 20,
      paddingHorizontal: 10,
      paddingVertical: 4,
    },
    badgeText: { fontSize: 12, color: colors.primary, fontWeight: "600" as const },
  });

  const lastSeen = user.locationUpdatedAt
    ? (() => {
        const mins = Math.floor((Date.now() - new Date(user.locationUpdatedAt).getTime()) / 60000);
        if (mins < 2) return "just now";
        if (mins < 60) return `${mins}m ago`;
        const hrs = Math.floor(mins / 60);
        if (hrs < 24) return `${hrs}h ago`;
        return `${Math.floor(hrs / 24)}d ago`;
      })()
    : null;

  return (
    <View style={s.card}>
      <Image
        source={{ uri: user.avatarUrl ?? `https://api.dicebear.com/9.x/personas/svg?seed=${user.id}` }}
        style={s.avatar}
      />
      <View style={s.info}>
        <Text style={s.name}>{user.name}, {user.age}</Text>
        <Text style={s.sub}>{user.gender}{lastSeen ? ` · ${lastSeen}` : ""}</Text>
        {user.bio ? <Text style={s.bio} numberOfLines={1}>{user.bio}</Text> : null}
      </View>
      <View style={s.badge}>
        <Ionicons name="location" size={12} color={colors.primary} />
        <Text style={s.badgeText}>{user.distanceKm} km</Text>
      </View>
    </View>
  );
}

export default function NearbyScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [permissionGranted, setPermissionGranted] = useState<boolean | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [radius, setRadius] = useState(25);
  const watchRef = useRef<Location.LocationSubscription | null>(null);

  const updateLocation = useUpdateLocation();
  const { data: nearbyUsersRaw, isLoading, refetch } = useGetNearbyUsers(
    { radius },
    { query: { enabled: permissionGranted === true, refetchInterval: 30000 } } as Parameters<typeof useGetNearbyUsers>[1]
  );
  const nearbyUsers: NearbyUser[] = (nearbyUsersRaw as NearbyUser[] | undefined) ?? [];

  const startTracking = useCallback(async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") {
      setPermissionGranted(false);
      setLocationError("Location permission is required to see who's nearby.");
      return;
    }
    setPermissionGranted(true);

    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    updateLocation.mutate({ data: { lat: loc.coords.latitude, lon: loc.coords.longitude } });

    watchRef.current = await Location.watchPositionAsync(
      { accuracy: Location.Accuracy.Balanced, distanceInterval: 100, timeInterval: 60000 },
      (pos) => {
        updateLocation.mutate({ data: { lat: pos.coords.latitude, lon: pos.coords.longitude } });
      }
    );
  }, []);

  useEffect(() => {
    startTracking();
    return () => { watchRef.current?.remove(); };
  }, []);

  const s = makeStyles(colors);

  if (permissionGranted === null) {
    return (
      <View style={[s.root, { paddingTop: insets.top }]}>
        <View style={s.center}>
          <ActivityIndicator color={colors.primary} size="large" />
          <Text style={s.loadingText}>Getting your location…</Text>
        </View>
      </View>
    );
  }

  if (permissionGranted === false) {
    return (
      <View style={[s.root, { paddingTop: insets.top }]}>
        <View style={s.header}><Text style={s.brand}>Nearby</Text></View>
        <View style={s.center}>
          <Ionicons name="location-outline" size={64} color={colors.mutedForeground} />
          <Text style={s.emptyTitle}>Location Needed</Text>
          <Text style={s.emptyText}>{locationError}</Text>
          <TouchableOpacity style={s.btn} onPress={startTracking} activeOpacity={0.8}>
            <Text style={s.btnText}>Allow Location</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={[s.root, { paddingTop: insets.top }]}>
      <View style={s.header}>
        <Text style={s.brand}>Nearby</Text>
        <View style={s.radiusPicker}>
          {[10, 25, 50].map(r => (
            <TouchableOpacity
              key={r}
              style={[s.radiusChip, radius === r && s.radiusChipActive]}
              onPress={() => setRadius(r)}
              activeOpacity={0.7}
            >
              <Text style={[s.radiusChipText, radius === r && s.radiusChipTextActive]}>
                {r}km
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {isLoading ? (
        <View style={s.center}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      ) : nearbyUsers.length === 0 ? (
        <View style={s.center}>
          <Ionicons name="people-outline" size={64} color={colors.mutedForeground} />
          <Text style={s.emptyTitle}>Nobody nearby yet</Text>
          <Text style={s.emptyText}>Check back when more people join</Text>
          <TouchableOpacity style={s.btn} onPress={() => refetch()} activeOpacity={0.8}>
            <Text style={s.btnText}>Refresh</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={nearbyUsers as NearbyUser[]}
          keyExtractor={item => String(item.id)}
          renderItem={({ item }) => <UserCard user={item} colors={colors} />}
          contentContainerStyle={{ paddingTop: 12, paddingBottom: insets.bottom + 90 }}
          showsVerticalScrollIndicator={false}
          onRefresh={() => refetch()}
          refreshing={isLoading}
          ListHeaderComponent={
            <Text style={s.count}>{nearbyUsers.length} people within {radius}km</Text>
          }
        />
      )}
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      paddingHorizontal: 20,
      paddingVertical: 12,
    },
    brand: { fontSize: 22, fontStyle: "italic", color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold" },
    radiusPicker: { flexDirection: "row", gap: 6 },
    radiusChip: {
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 20,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.card,
    },
    radiusChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
    radiusChipText: { fontSize: 12, color: colors.mutedForeground },
    radiusChipTextActive: { color: colors.primaryForeground, fontWeight: "600" as const },
    center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12, padding: 24 },
    loadingText: { fontSize: 14, color: colors.mutedForeground, marginTop: 8 },
    emptyTitle: { fontSize: 20, color: colors.foreground, fontFamily: "PlayfairDisplay_700Bold", textAlign: "center" },
    emptyText: { fontSize: 14, color: colors.mutedForeground, textAlign: "center", lineHeight: 20 },
    btn: {
      backgroundColor: colors.primary,
      borderRadius: 24,
      paddingHorizontal: 28,
      paddingVertical: 12,
      marginTop: 8,
    },
    btnText: { color: colors.primaryForeground, fontWeight: "600" as const, fontSize: 14 },
    count: { fontSize: 12, color: colors.mutedForeground, textAlign: "center", marginBottom: 8 },
  });
}
